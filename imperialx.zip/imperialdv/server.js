const express = require('express');
const cors = require('cors');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
const app = express();
const port = 5000;
const senhaAuth = 'nor'; // troca pra outra senha.
const dbPath = './public/database/links.json';
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
const limiter = rateLimit({
windowMs: 60 * 1000,
max: 100,
});
app.use(limiter);
const getLinks = () => {
return JSON.parse(fs.readFileSync(dbPath));
};
app.get('/api/links', (req, res) => {
const links = getLinks();
res.json(links);
});
app.post('/api/atualizar', (req, res) => {
const { senha, telegram1, telegram2, whatsapp } = req.body;
if (senha !== senhaAuth) {
return res.status(403).json({ erro: 'Acesso negado, senha incorreta.' });
}
const dadosAtuais = getLinks();
const novosDados = {
telegram1: telegram1 || dadosAtuais.telegram1,
telegram2: telegram2 || dadosAtuais.telegram2,
whatsapp: whatsapp || dadosAtuais.whatsapp,
};
fs.writeFileSync(dbPath, JSON.stringify(novosDados, null, 2));
res.json({ msg: 'Links atualizados com sucesso!', dados: novosDados });
});
app.get('/painel', (req, res) => {
res.sendFile(__dirname + '/public/painel.html');
});
app.listen(port, () => {
console.log(`Servidor rodando em: http://localhost:${port}`);
});